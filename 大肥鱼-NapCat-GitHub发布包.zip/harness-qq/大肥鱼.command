#!/bin/zsh
# 大肥鱼 · 一键启动器
#   双击：打开菜单
#   参数：start / stop / status / autostart-install / autostart-remove / --headless
# 说明：QQ 必须从普通终端启动（不能在 DSH 沙箱里），本脚本天然满足。
emulate -L zsh
setopt nullglob

ROOT="${0:A:h}"
NODE="$(command -v node 2>/dev/null)"
[[ -n "$NODE" ]] || NODE="$ROOT/runtime/node-v22.23.4-darwin-arm64/bin/node"
CONSOLE_DIR="$ROOT/qq-console"
CONSOLE_LOG="$CONSOLE_DIR/server.log"
QQ_LOG_DIR="$ROOT/runtime"
QQ_BIN="/Applications/QQ.app/Contents/MacOS/QQ"
PLIST="$HOME/Library/LaunchAgents/com.dafishu.qqbot.plist"
CONSOLE_PORT=${QQ_CONSOLE_PORT:-8788}
WS_PORT=8644
NAPCAT_PORT=6099

c_ok=$'\033[32m'; c_warn=$'\033[33m'; c_err=$'\033[31m'; c_dim=$'\033[2m'; c_off=$'\033[0m'
say()  { print -r -- "${c_dim}·${c_off} $*" }
ok()   { print -r -- "${c_ok}✓${c_off} $*" }
warn() { print -r -- "${c_warn}!${c_off} $*" }
err()  { print -r -- "${c_err}✗${c_off} $*" }

port_listen() { lsof -nP -iTCP:"$1" -sTCP:LISTEN >/dev/null 2>&1 }
port_conn()   { lsof -nP -iTCP:"$1" -sTCP:ESTABLISHED 2>/dev/null | grep -c ESTABLISHED }

# ---------- 各组件启停 ----------

dsh_running() { port_listen "$WS_PORT"; }

start_dsh() {
  if dsh_running; then ok "DSH 已在运行（插件监听 $WS_PORT）"; return 0; fi
  say "启动 DeepSeek Harness…"
  open -a "DeepSeek Harness" 2>/dev/null || { err "找不到 DeepSeek Harness.app"; return 1; }
  local i=0
  while (( i++ < 60 )); do
    sleep 1
    if dsh_running; then ok "DSH 就绪，QQ 通道监听 $WS_PORT"; return 0; fi
  done
  warn "等了 60 秒插件端口还没起来；DSH 可能在加载，稍后自动重试"
  return 1
}

qq_running() { pgrep -f "$QQ_BIN" >/dev/null 2>&1 }

start_qq() {
  if port_listen "$NAPCAT_PORT"; then ok "QQ / NapCat 已在运行"; return 0; fi
  if qq_running; then err "QQ 进程存在但 NapCat 未就绪，请先检查 QQ 登录或启动日志"; return 1; fi
  say "启动 QQ（NapCat 注入模式）…"
  local log="$QQ_LOG_DIR/qq-$(date +%Y%m%d-%H%M%S).log"
  nohup "$QQ_BIN" --no-sandbox >> "$log" 2>&1 &
  disown
  local i=0
  while (( i++ < 60 )); do
    sleep 1
    if port_listen "$NAPCAT_PORT"; then
      ok "NapCat 就绪（WebUI $NAPCAT_PORT）"
      print -r -- "    日志：$log"
      return 0
    fi
  done
  err "NapCat 60 秒内没起来，看日志：$log"
  return 1
}

bot_online() {
  curl -s -m 3 "http://127.0.0.1:$CONSOLE_PORT/api/overview" 2>/dev/null | grep -q '"online":true'
}

start_console() {
  if port_listen "$CONSOLE_PORT"; then ok "控制台已在运行"; return 0; fi
  [[ -x "$NODE" ]] || { err "缺少内置 Node：$NODE"; return 1; }
  say "启动控制台…"
  ( cd "$CONSOLE_DIR" && nohup "$NODE" server.mjs >> "$CONSOLE_LOG" 2>&1 & ) 
  local i=0
  while (( i++ < 20 )); do
    sleep 0.5
    if port_listen "$CONSOLE_PORT"; then ok "控制台就绪：http://127.0.0.1:$CONSOLE_PORT"; return 0; fi
  done
  err "控制台没起来，看 $CONSOLE_LOG"
  return 1
}

stop_all() {
  say "停止 QQ（NapCat 随之退出）…"
  local pids=($(pgrep -f "$QQ_BIN" 2>/dev/null))
  (( ${#pids} )) && kill -TERM "${pids[@]}" 2>/dev/null
  sleep 3
  pids=($(pgrep -f "$QQ_BIN" 2>/dev/null))
  (( ${#pids} )) && kill -9 "${pids[@]}" 2>/dev/null
  ok "QQ 已停止"

  say "停止控制台…"
  local cpids=($(lsof -nP -iTCP:"$CONSOLE_PORT" -sTCP:LISTEN -t 2>/dev/null))
  (( ${#cpids} )) && kill "${cpids[@]}" 2>/dev/null
  ok "控制台已停止"
  say "DSH 桌面版未关闭（关掉它的窗口即可）"
}

show_status() {
  print -r -- ""
  if dsh_running; then ok "DSH / 插件   监听 $WS_PORT"; else err "DSH / 插件   未运行"; fi
  if qq_running;   then ok "QQ 进程      运行中";        else err "QQ 进程      未运行"; fi
  if port_listen "$NAPCAT_PORT"; then ok "NapCat       就绪（$NAPCAT_PORT）"; else warn "NapCat       未就绪"; fi
  local n=$(port_conn "$WS_PORT")
  if (( n > 0 )); then ok "QQ ↔ DSH     已连接（$n 条）"; else warn "QQ ↔ DSH     未连接"; fi
  if port_listen "$CONSOLE_PORT"; then ok "控制台       http://127.0.0.1:$CONSOLE_PORT"; else warn "控制台       未运行"; fi
  if bot_online; then ok "机器人       在线"; else warn "机器人       离线或未登录"; fi
  [[ -f "$PLIST" ]] && ok "开机自启     已安装" || say "开机自启     未安装（菜单 4 可装）"
}

open_console() { open "http://127.0.0.1:$CONSOLE_PORT" 2>/dev/null; }

start_all() {
  print -r -- ""
  print -r -- "  大肥鱼 · 启动中"
  print -r -- "  ─────────────────────────────"
  start_dsh
  start_qq
  start_console
  print -r -- "  ─────────────────────────────"
  show_status
  open_console
  print -r -- ""
  say "机器人没回消息时，先看状态里「QQ ↔ DSH」是否为已连接"
}

# ---------- 开机自启 ----------

install_autostart() {
  mkdir -p "$(dirname "$PLIST")"
  cat > "$PLIST" <<EOF
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.dafishu.qqbot</string>
  <key>ProgramArguments</key>
  <array>
    <string>$NODE</string>
    <string>$CONSOLE_DIR/server.mjs</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><true/>
  <key>WorkingDirectory</key><string>$CONSOLE_DIR</string>
  <key>EnvironmentVariables</key>
  <dict><key>PATH</key><string>/usr/bin:/bin:/usr/sbin:/sbin</string></dict>
  <key>StandardOutPath</key><string>$ROOT/runtime/autostart.log</string>
  <key>StandardErrorPath</key><string>$ROOT/runtime/autostart.err.log</string>
</dict>
</plist>
EOF
  launchctl unload "$PLIST" >/dev/null 2>&1
  launchctl load "$PLIST" >/dev/null 2>&1
  ok "已安装开机自启（登录后自动启动网页后台，QQ 和模型在页面里启动）"
}

remove_autostart() {
  launchctl unload "$PLIST" >/dev/null 2>&1
  rm -f "$PLIST"
  ok "已移除开机自启"
}

# ---------- 入口 ----------

case "${1:-web}" in
  web) start_console && open_console ;;
  console) start_console ;;
  services) start_dsh && start_qq ;;
  start) start_all ;;
  stop) stop_all ;;
  status) show_status ;;
  autostart-install) install_autostart ;;
  autostart-remove) remove_autostart ;;
  --headless) start_all >/dev/null 2>&1 ;;
  menu)
    while true; do
      print -r -- ""
      print -r -- "  🐟 大肥鱼 · QQ 控制台"
      print -r -- "  ─────────────────────────────"
      show_status
      print -r -- "  ─────────────────────────────"
      print -r -- "  1) 一键启动（DSH + QQ + 控制台）"
      print -r -- "  2) 打开控制台网页"
      print -r -- "  3) 停止 QQ 和控制台"
      print -r -- "  4) 安装开机自启"
      print -r -- "  5) 移除开机自启"
      print -r -- "  q) 退出"
      print -r -- ""
      read -r "?  请选择: " choice
      case "$choice" in
        1) start_all; print -r -- ""; read -r "?  按回车返回菜单…" _ ;;
        2) open_console ;;
        3) stop_all; print -r -- ""; read -r "?  按回车返回菜单…" _ ;;
        4) install_autostart; read -r "?  按回车返回菜单…" _ ;;
        5) remove_autostart; read -r "?  按回车返回菜单…" _ ;;
        q|Q) exit 0 ;;
      esac
    done
    ;;
  *) print -r -- "用法: $0 [start|stop|status|autostart-install|autostart-remove]" ;;
esac
