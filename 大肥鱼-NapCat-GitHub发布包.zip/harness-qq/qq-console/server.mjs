#!/usr/bin/env node
/**
 * QQ 控制台 —— 本地可视化面板（只监听 127.0.0.1）
 *
 * 数据来源：
 *  - DSH 插件配置： ~/.dsh/profiles/desktop/cordis.patch.yml 的 `- id: dsh-onebot` 块
 *  - 机器人状态/消息：NapCat WebUI API  http://127.0.0.1:6099/api
 *
 * 不做任何外网访问；写配置前会在同目录留 .before-console 备份。
 */
import { createServer } from 'node:http';
import { readFile, writeFile, readdir, stat, copyFile, rename } from 'node:fs/promises';
import { existsSync } from 'node:fs';
import { execFile, spawn } from 'node:child_process';
import { promisify } from 'node:util';
import { createHash } from 'node:crypto';
import { homedir } from 'node:os';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.QQ_CONSOLE_PORT || 8788);
const NAPCAT = 'http://127.0.0.1:6099/api';
const PROFILE = join(homedir(), '.dsh', 'profiles', 'desktop', 'cordis.patch.yml');
const PLUGIN_ID = 'dsh-onebot';
const WS_PORT = 8644;

const exec = promisify(execFile);
const ROOT = join(HERE, '..');
const startJob = { running: false, startedAt: null, finishedAt: null, exitCode: null, log: '' };

async function portOpen(port) {
  try { await exec('/usr/sbin/lsof', ['-nP', `-iTCP:${port}`, '-sTCP:LISTEN'], { timeout: 2500 }); return true; }
  catch { return false; }
}

async function runtimeStatus() {
  const [model, napcatReady, bridges] = await Promise.all([portOpen(WS_PORT), portOpen(6099), wsEstablished()]);
  return { model, napcat: napcatReady, bridges, job: { ...startJob } };
}

function startServices() {
  if (startJob.running) return { ok: true, alreadyRunning: true };
  Object.assign(startJob, { running: true, startedAt: new Date().toISOString(), finishedAt: null, exitCode: null, log: '' });
  const child = spawn('/bin/zsh', [join(ROOT, '大肥鱼.command'), 'services'], {
    cwd: ROOT, env: { ...process.env, TERM: 'dumb' }, stdio: ['ignore', 'pipe', 'pipe'],
  });
  const append = (chunk) => { startJob.log = (startJob.log + chunk.toString().replace(/\x1b\[[0-9;]*m/g, '')).slice(-18000); };
  child.stdout.on('data', append);
  child.stderr.on('data', append);
  child.on('error', (err) => { append(err.message); });
  child.on('close', (code) => { Object.assign(startJob, { running: false, exitCode: code ?? 1, finishedAt: new Date().toISOString() }); });
  return { ok: true };
}

/* ------------------------------------------------------------------ 配置读写 */

const MANAGED_KEYS = [
  'mode', 'host', 'port', 'url', 'accessToken', 'botQQ',
  'dmPolicy', 'allowFrom', 'adminUsers', 'allowAllUsers',
  'groupPolicy', 'groupAllowFrom', 'requireMention',
  'interimMessages', 'rateLimitPerMinute', 'logLevel',
  'agentPreset', 'workspacePath', 'recordInbound', 'traceEnabled',
];

function parseScalar(raw) {
  const v = raw.trim();
  if (v === '[]') return [];
  if (v === 'true') return true;
  if (v === 'false') return false;
  if (v === '') return '';
  if (/^-?\d+$/.test(v)) return Number(v);
  if ((v.startsWith('"') && v.endsWith('"')) || (v.startsWith("'") && v.endsWith("'"))) {
    return v.slice(1, -1);
  }
  return v;
}

function parseBlock(lines) {
  // lines: the `- id: dsh-onebot` block; returns { keys: orderedIds, config }
  const config = {};
  const order = [];
  let inConfig = false;
  let currentListKey = null;
  for (const line of lines) {
    if (/^\s*#/.test(line)) continue;
    if (/^  config:\s*$/.test(line)) { inConfig = true; continue; }
    if (!inConfig) continue;
    const kv = line.match(/^ {4}([A-Za-z0-9_]+):\s*(.*)$/);
    if (kv) {
      const [, key, rest] = kv;
      if (!(key in config)) order.push(key);
      if (rest.trim() === '') {
        config[key] = [];
        currentListKey = key;
      } else {
        config[key] = parseScalar(rest);
        currentListKey = null;
      }
      continue;
    }
    const item = line.match(/^ {6}- (.*)$/);
    if (item && currentListKey) {
      config[currentListKey].push(parseScalar(item[1]));
      continue;
    }
    if (/^ {0,2}\S/.test(line)) break;
  }
  return { order, config };
}

async function readConfig() {
  const text = await readFile(PROFILE, 'utf8');
  const lines = text.split('\n');
  const start = lines.findIndex((l) => new RegExp(`^- id: ${PLUGIN_ID}\\s*$`).test(l));
  if (start === -1) return { text, lines, start: -1, end: -1, order: [], config: {} };
  let end = lines.length;
  for (let i = start + 1; i < lines.length; i += 1) {
    if (/^- /.test(lines[i])) { end = i; break; }
  }
  const { order, config } = parseBlock(lines.slice(start, end));
  return { text, lines, start, end, order, config };
}

function scalar(value) {
  if (typeof value === 'boolean' || typeof value === 'number') return String(value);
  return JSON.stringify(String(value));
}

function buildBlock(order, config) {
  const out = [`- id: ${PLUGIN_ID}`, '  config:'];
  for (const key of order) {
    const value = config[key];
    if (Array.isArray(value)) {
      if (value.length === 0) { out.push(`    ${key}: []`); continue; }
      out.push(`    ${key}:`);
      for (const item of value) out.push(`      - ${scalar(item)}`);
    } else {
      out.push(`    ${key}: ${scalar(value)}`);
    }
  }
  return out;
}

async function writeConfig(patch) {
  const { lines, start, end, order, config } = await readConfig();
  if (start === -1) throw new Error('profile 里找不到 dsh-onebot 配置块');
  const next = { ...config, ...patch };
  const block = lines.slice(start, end);
  for (const [key, value] of Object.entries(patch)) {
    let at = block.findIndex(line => new RegExp(`^ {4}${key}:`).test(line));
    const replacement = buildBlock([key], { [key]: value }).slice(2);
    if (at < 0) { at = block.findIndex(line => /^  config:\s*$/.test(line)) + 1; if (!at) throw new Error('未找到插件配置'); block.splice(at, 0, ...replacement); }
    else {
      let stop = at + 1;
      while (stop < block.length && (/^ {6}- /.test(block[stop]) || /^\s*$/.test(block[stop]))) stop++;
      block.splice(at, stop - at, ...replacement);
    }
  }
  const backup = PROFILE + '.before-console';
  if (!existsSync(backup)) await copyFile(PROFILE, backup);
  const merged = [...lines.slice(0, start), ...block, ...lines.slice(end)];
  await writeFile(PROFILE, merged.join('\n').replace(/\n*$/, '\n'), 'utf8');
  return next;
}

/* --------------------------------------------------------------- NapCat 通道 */

let credential = null;

async function findWebUiToken() {
  const dirs = [
    join(HERE, '..', 'qq-logs'),
    join(HERE, '..', 'data'),
    join(homedir(), 'Documents', 'deepseek-harness', 'default-workspace', 'qq-logs'),
    join(HERE, '..', 'runtime'),
  ];
  const candidates = [];
  for (const dir of dirs) {
    if (!existsSync(dir)) continue;
    for (const name of await readdir(dir)) {
      if (!name.endsWith('.log')) continue;
      const full = join(dir, name);
      candidates.push({ full, mtime: (await stat(full)).mtimeMs });
    }
  }
  candidates.sort((a, b) => b.mtime - a.mtime);
  for (const { full } of candidates.slice(0, 8)) {
    const text = await readFile(full, 'utf8').catch(() => '');
    const matches = [...text.matchAll(/WebUi Token:\s*([A-Za-z0-9]+)/g)];
    if (matches.length) return matches[matches.length - 1][1];
  }
  return null;
}

async function login() {
  const token = await findWebUiToken();
  if (!token) throw new Error('没找到 NapCat WebUi Token（QQ 是否在跑？）');
  const hash = createHash('sha256').update(`${token}.napcat`).digest('hex');
  const res = await fetch(`${NAPCAT}/auth/login`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    signal: AbortSignal.timeout(4000),
    body: JSON.stringify({ hash }),
  });
  const data = await res.json();
  if (data.code !== 0) throw new Error(data.message || 'NapCat 登录失败');
  credential = data.data.Credential;
  return credential;
}

async function napcat(action, params = {}, retry = true) {
  if (!credential) await login();
  const res = await fetch(`${NAPCAT}/Debug/call`, {
    method: 'POST',
    headers: { 'content-type': 'application/json', authorization: `Bearer ${credential}` },
    signal: AbortSignal.timeout(4000),
    body: JSON.stringify({ action, params }),
  });
  const data = await res.json().catch(() => ({ code: -1, message: '响应不是 JSON' }));
  if (data.code !== 0 && retry) { await login(); return napcat(action, params, false); }
  return data;
}

async function loginInfo(retry = true) {
  if (!credential) await login();
  const res = await fetch(`${NAPCAT}/QQLogin/GetQQLoginInfo`, {
    method: 'POST',
    headers: { authorization: `Bearer ${credential}` },
    signal: AbortSignal.timeout(4000),
  });
  const data = await res.json();
  if (data.code !== 0) {
    if (!retry) throw new Error(data.message || 'QQ 登录信息读取失败');
    await login(); return loginInfo(false);
  }
  return data.data;
}

async function wsEstablished() {
  try {
    const { stdout } = await exec('/usr/sbin/lsof', ['-nP', `-iTCP:${WS_PORT}`, '-sTCP:ESTABLISHED'], { timeout: 2500 });
    return stdout.split('\n').filter((l) => l.includes('ESTABLISHED')).length;
  } catch {
    return 0;
  }
}

/* ------------------------------------------------------------------- HTTP 层 */

function json(res, code, body) {
  const payload = JSON.stringify(body);
  res.writeHead(code, { 'content-type': 'application/json; charset=utf-8', 'cache-control': 'no-store' });
  res.end(payload);
}

async function body(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString('utf8');
  return raw ? JSON.parse(raw) : {};
}

function segmentsToText(message) {
  if (typeof message === 'string') return message;
  if (!Array.isArray(message)) return '';
  return message.map((seg) => {
    if (!seg || typeof seg !== 'object') return '';
    const d = seg.data || {};
    switch (seg.type) {
      case 'text': return d.text || '';
      case 'image': return '[图片]';
      case 'face': return '[表情]';
      case 'record': return '[语音]';
      case 'video': return '[视频]';
      case 'file': return `[文件${d.name ? ' ' + d.name : ''}]`;
      case 'at': return `@${d.qq === 'all' ? '全体成员' : d.qq}`;
      case 'reply': return '[引用]';
      case 'forward': return '[合并转发]';
      default: return '';
    }
  }).join('');
}

function shapeMessages(list, selfId) {
  return (list || []).map((m) => {
    const sender = m.sender || {};
    const uid = String(sender.user_id ?? m.user_id ?? '');
    return {
      id: String(m.message_id ?? ''),
      time: Number(m.time ?? 0) * (String(m.time ?? '').length > 10 ? 1 : 1000),
      from: String(sender.card || sender.nickname || uid),
      uid,
      self: uid === String(selfId),
      text: segmentsToText(m.message),
    };
  });
}

async function overview() {
  const { config } = await readConfig();
  let bot = null;
  let groups = [];
  let error = null;
  try {
    bot = await loginInfo();
    const g = await napcat('get_group_list', {});
    groups = (g.data?.data || []).map((x) => ({ id: String(x.group_id), name: x.group_name }));
  } catch (e) {
    error = e.message;
  }
  const chats = [];
  for (const g of groups) chats.push({ type: 'group', id: g.id, name: g.name });
  for (const id of config.allowFrom || []) {
    chats.push({ type: 'private', id: String(id), name: `私聊 ${id}` });
  }
  return {
    bot,
    error,
    chats,
    ws: await wsEstablished(),
    config,
    profile: PROFILE,
    wsPort: config.port,
  };
}

async function history(type, id) {
  const bot = await loginInfo();
  const action = type === 'group' ? 'get_group_msg_history' : 'get_friend_msg_history';
  const params = type === 'group'
    ? { group_id: Number(id), count: 30 }
    : { user_id: Number(id), count: 30 };
  const data = await napcat(action, params);
  const list = data.data?.data?.messages || data.data?.messages || [];
  return { messages: shapeMessages(list, bot.uin) };
}

const routes = {
  'GET /api/runtime': async () => runtimeStatus(),
  'POST /api/start': async () => startServices(),
  'POST /api/login-page': async () => {
    if (!(await portOpen(6099))) throw new Error('请先启动 QQ，等待 NapCat 就绪');
    const token = await findWebUiToken();
    if (!token) throw new Error('未找到登录密钥，请先启动 QQ / NapCat 后重试');
    const url = new URL('http://127.0.0.1:6099/webui');
    url.searchParams.set('token', token);
    await exec('/usr/bin/open', [url.href], { timeout: 5000 });
    return { ok: true };
  },
  'GET /api/overview': async () => overview(),
  'GET /api/messages': async (req, url) => history(url.searchParams.get('type'), url.searchParams.get('id')),
  'POST /api/config': async (req) => {
    const patch = await body(req);
    const allowed = {};
    for (const key of Object.keys(patch)) {
      if (MANAGED_KEYS.includes(key)) allowed[key] = patch[key];
    }
    const next = await writeConfig(allowed);
    return { ok: true, config: next, note: '已写入 cordis.patch.yml，插件会在数秒内热重载' };
  },
  'POST /api/send': async (req) => {
    const { type, id, text } = await body(req);
    if (!text || !id) throw new Error('缺少 id 或 text');
    const action = type === 'group' ? 'send_group_msg' : 'send_private_msg';
    const params = type === 'group'
      ? { group_id: Number(id), message: text }
      : { user_id: Number(id), message: text };
    const data = await napcat(action, params);
    if (data.code !== 0 || data.data?.retcode !== 0) {
      throw new Error(data.data?.message || data.message || '发送失败');
    }
    return { ok: true, messageId: data.data?.data?.message_id };
  },
};

const server = createServer(async (req, res) => {
  try {
    const host = req.headers.host;
    if (![ `127.0.0.1:${PORT}`, `localhost:${PORT}` ].includes(host)) return json(res, 403, { ok: false, error: '仅允许本机访问' });
    if (req.method !== 'GET' && (req.headers.origin && ![`http://127.0.0.1:${PORT}`, `http://localhost:${PORT}`].includes(req.headers.origin) || req.headers['sec-fetch-site'] === 'cross-site')) return json(res, 403, { ok: false, error: '拒绝跨站操作' });
    const url = new URL(req.url, `http://${host}`);
    if (url.pathname === '/' || url.pathname === '/index.html') {
      const html = await readFile(join(HERE, 'public', 'index.html'));
      res.writeHead(200, { 'content-type': 'text/html; charset=utf-8', 'cache-control': 'no-store' });
      res.end(html);
      return;
    }
    const handler = routes[`${req.method} ${url.pathname}`];
    if (!handler) return json(res, 404, { ok: false, error: 'not found' });
    json(res, 200, await handler(req, url));
  } catch (e) {
    json(res, 500, { ok: false, error: e.message });
  }
});

server.listen(PORT, '127.0.0.1', () => {
  console.log(`QQ 控制台已启动: http://127.0.0.1:${PORT}`);
});
